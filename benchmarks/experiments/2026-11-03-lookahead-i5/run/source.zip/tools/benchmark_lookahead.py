"""Paired decode lookahead protocol; invoked only through run_benchmark.py."""
import copy
import hashlib
import math
import statistics

import run_benchmark as common


def validate_protocol(args):
    if args.http_scenario != 'topics' or args.compare_cache_policies or args.suite or args.case:
        raise ValueError('--compare-lookahead requires topics, no policy comparison or suite')
    if args.gpu != 'cpu':
        raise ValueError('lookahead-v1 requires CPU mode; GPU needs a fixed VRAM budget protocol')
    if args.expert_cache_policy != 'victim':
        raise ValueError('lookahead-v1 fixes victim policy')


def block_plan(pairs):
    return [{'pair': pair, 'mode': mode} for pair in range(pairs)
            for mode in (('off', 'on') if pair % 2 == 0 else ('on', 'off'))]


def source_fingerprint(root):
    # All tracked/untracked inference/tooling inputs, plus build manifests and fixtures.
    # Avoid including benchmark output and documentation edited by a concurrent IDE.
    paths = [root / name for name in ('Cargo.toml', 'Cargo.lock', 'build.rs')]
    for name in ('src', 'tools', 'tests/fixtures'):
        paths.extend(p for p in (root / name).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(paths) if p.is_file()}


def validate_sample(sample, enabled, status, cache_mib):
    m = sample['response']['metrics']
    if m.get('lookahead_enabled') is not enabled:
        raise ValueError('request lookahead mode mismatch')
    counts = m.get('lookahead', {})
    fields = ('eligible_layers', 'proposed', 'loaded', 'load_errors', 'used', 'unused',
              'abandoned', 'pending', 'file_bytes', 'buffer_peak_bytes')
    if any(type(counts.get(k)) is not int or counts[k] < 0 for k in fields):
        raise ValueError('missing/invalid lookahead counters')
    if counts['proposed'] != counts['loaded'] + counts['load_errors']:
        raise ValueError('lookahead proposal accounting mismatch')
    if counts['loaded'] != sum(counts[k] for k in ('used', 'unused', 'abandoned', 'pending')):
        raise ValueError('lookahead lifecycle accounting mismatch')
    if counts['pending'] or counts['abandoned'] or counts['load_errors']:
        raise ValueError('unfinished/failed speculative work in completed request')
    if not enabled and any(counts[k] for k in fields if k != 'eligible_layers'):
        raise ValueError('disabled mode performed speculative work')
    for key in ('decode_ms', 'total_ms', 'time_to_first_token_ms', 'decode_tokens_per_second'):
        value = m.get(key)
        if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
            raise ValueError('invalid timing: ' + key)
    if m.get('cached_prompt_tokens') != 0:
        raise ValueError('independent workload unexpectedly reused prefix KV')
    active_limit = status['expert_request_payload_limit_bytes']
    host_limit = status['num_layers'] * cache_mib * 1024**2 + active_limit
    for key, limit in (('decode_expert_active_peak_bytes', active_limit),
                       ('decode_expert_host_peak_bytes', host_limit)):
        value = m.get(key)
        if type(value) is not int or not 0 <= value <= limit:
            raise ValueError('expert capacity reserve exceeded: ' + key)
    if counts['buffer_peak_bytes'] > m['decode_expert_active_peak_bytes']:
        raise ValueError('speculative buffers missing from active capacity')
    return counts['loaded']


def compare_pair(off, on):
    if len(off) != len(on) or not off:
        raise ValueError('incomplete paired block')
    rows = []
    for a, b in zip(off, on):
        ra, rb = a['response'], b['response']
        if (a['messages'] != b['messages'] or ra['usage'] != rb['usage'] or
                ra['text'] != rb['text'] or ra['finish_reason'] != rb['finish_reason']):
            raise ValueError('paired workload/output mismatch; inspect preserved block files')
        deltas = {}
        for key in ('decode_ms', 'total_ms', 'time_to_first_token_ms', 'decode_tokens_per_second'):
            av, bv = ra['metrics'][key], rb['metrics'][key]
            deltas[key] = {'off': av, 'on': bv, 'on_minus_off': bv - av,
                           'change_pct': (bv / av - 1) * 100 if av > 0 else None}
        rows.append({'prompt': a['prompt'], 'turn': a['turn'], 'metrics': deltas})
    return rows


def measure_paired(binary, model, args, env, directory, root, measure):
    validate_protocol(args)
    from benchmark_http_session import scenario_spec
    expected_prompts = scenario_spec("topics")["prompts"]
    fingerprint = source_fingerprint(root)
    binary_hash = hashlib.sha256(binary.read_bytes()).hexdigest()
    blocks, pending, pairs = [], {}, []
    loaded = 0
    def checkpoint_state():
        return {str(p.relative_to(model)): (p.stat().st_size, p.stat().st_mtime_ns)
                for p in model.rglob('*') if p.is_file()}
    checkpoint_before = checkpoint_state()
    for index, entry in enumerate(block_plan(args.runs)):
        if checkpoint_state() != checkpoint_before:
            raise ValueError('checkpoint metadata drift during paired experiment')
        if source_fingerprint(root) != fingerprint or hashlib.sha256(binary.read_bytes()).hexdigest() != binary_hash:
            raise ValueError('source/binary drift during paired experiment')
        block = directory / f"block-{index:02d}-{entry['mode']}"
        block.mkdir()
        block_args = copy.copy(args)
        block_args.runs = 1
        block_args.compare_lookahead = False
        block_args.lookahead = entry['mode']
        result = measure(binary, model, block_args, env.copy(), block)
        common.write_exclusive_json(block / 'result.json', {'protocol': 'lookahead-v1', **entry, 'result': result})
        if [r['prompt'] for r in result['runs']] != expected_prompts or result['warmups']:
            raise ValueError('incomplete or unexpected topics block')
        status = result['status_start']
        for state in (status, result['status_end']):
            if state['cache_bytes_per_layer'] != args.cache * 1024**2:
                raise ValueError('cache budget changed')
            if state['gpu']['enabled'] != (args.gpu == 'auto'):
                raise ValueError('backend changed during block')
            if state['lookahead_enabled'] is not (entry['mode'] == 'on'):
                raise ValueError('lookahead changed during block')
            if any(layer['cache_bytes'] + layer['recycled_bytes'] > args.cache * 1024**2 for layer in state['layers']):
                raise ValueError('retained cache/pool budget exceeded')
        for sample in result['runs']:
            loaded += validate_sample(sample, entry['mode'] == 'on', status, args.cache)
        blocks.append({**entry, 'path': str(block.relative_to(directory))})
        pending[entry['mode']] = result['runs']
        if index % 2 == 1:
            rows = compare_pair(pending['off'], pending['on'])
            pairs.append({'pair': entry['pair'], 'rows': rows})
            common.write_exclusive_json(directory / f"pair-{entry['pair']}.json", pairs[-1])
            pending.clear()
    if checkpoint_state() != checkpoint_before:
        raise ValueError('checkpoint metadata drift at completion')
    if source_fingerprint(root) != fingerprint or hashlib.sha256(binary.read_bytes()).hexdigest() != binary_hash:
        raise ValueError('source/binary drift at completion')
    summary = []
    for turn in range(len(pairs[0]['rows'])):
        metrics = {}
        for key in pairs[0]['rows'][turn]['metrics']:
            changes = [p['rows'][turn]['metrics'][key]['change_pct'] for p in pairs]
            changes = [v for v in changes if v is not None]
            metrics[key] = {'paired_change_pct_median': statistics.median(changes) if changes else None,
                            'min': min(changes) if changes else None, 'max': max(changes) if changes else None}
        summary.append({'prompt': pairs[0]['rows'][turn]['prompt'], 'metrics': metrics})
    return {'protocol': 'lookahead-v1', 'blocks': blocks, 'pairs': pairs, 'summary': summary,
            'activation': 'observed' if loaded else 'no_speculative_loads',
            'limits': ['HTTP text/usage parity, not full-model logits parity',
                       'sampled decode expert capacity, not hard RSS cap',
                       'CPU mode may allocate VRAM during load; OS cache uncontrolled']}
