"""Bounded CPU cache admission experiment at fixed cache capacity."""
import datetime
import json
import os
from pathlib import Path
import uuid
import benchmark_gate_up as kernel
import benchmark_gate_up_model as model
import check_ram_stability as ram
import run_benchmark as common

MODES=("always","frequency","frequency","always")


def validate_block(record,mode):
    model.validate_block(record,"paired")
    for status in [record["status_start"],*(t["status"] for t in record["turns"])]:
        if status.get("cache_admission")!=mode:
            raise ValueError("cache admission mode mismatch")
    for turn in record["turns"]:
        metrics=turn["response"]["metrics"]
        if metrics.get("cache_admission")!=mode or type(metrics.get("expert_cache_admission_bypasses")) is not int:
            raise ValueError("missing admission telemetry")
        if mode=="always" and metrics["expert_cache_admission_bypasses"]:
            raise ValueError("baseline unexpectedly bypassed admission")


def compare_blocks(before,after):
    for key in ("source_sha256","binary_sha256","checkpoint"):
        if before[key]!=after[key]:raise ValueError("source/binary/checkpoint drift")
    ignored=("cache_admission","output_root")
    if ({k:v for k,v in before["config"].items() if k not in ignored}
            !={k:v for k,v in after["config"].items() if k not in ignored}):
        raise ValueError("config drift")
    for a,b in zip(before["turns"],after["turns"]):
        if a["messages"]!=b["messages"]:raise ValueError("input drift")
        for key in ("text","usage","finish_reason"):
            if a["response"][key]!=b["response"][key]:raise ValueError("output parity failed")


def summarize(records):
    pairs=[]
    for pair,(a,b) in enumerate(((records[0],records[1]),(records[3],records[2]))):
        for prompt,(x,y) in enumerate(zip(a["turns"],b["turns"])):
            am,bm=x["response"]["metrics"],y["response"]["metrics"]
            loads_a,loads_b=am["expert_file_loads"],bm["expert_file_loads"]
            bytes_a,bytes_b=am["expert_file_bytes_read"],bm["expert_file_bytes_read"]
            if min(loads_a,bytes_a)<=0 or min(loads_b,bytes_b)<0:raise ValueError("invalid I/O counters")
            pairs.append({"pair":pair,"prompt_position":prompt,
                          "file_loads":{"always":loads_a,"frequency":loads_b,"reduction":1-loads_b/loads_a},
                          "file_payload_bytes":{"always":bytes_a,"frequency":bytes_b,"reduction":1-bytes_b/bytes_a},
                          "bypasses":bm["expert_cache_admission_bypasses"],
                          "total_ms":{"always":am["total_ms"],"frequency":bm["total_ms"]},
                          "expert_compute_ms":{"always":am["expert_compute_ms"],"frequency":bm["expert_compute_ms"]}})
    return {"pairs":pairs,"passes_payload_rule":all(p["file_loads"]["reduction"]>=.05
                                                   and p["file_payload_bytes"]["reduction"]>=.05 for p in pairs),
            "rule":"at least 5% fewer file loads/payload in each prompt/pair; parity required; no physical SSD or timing claim"}


def execute(args,root):
    if (args.gpu!="cpu" or args.threads!=4 or args.cache!=64 or args.context!=512
            or args.max_tokens!=32 or args.lookahead!="off" or args.http_session or args.suite
            or args.case or args.compare_lookahead or args.compare_cache_policies):
        raise ValueError("admission protocol requires CPU4/cache64/context512/max32/lookahead off, no other suite")
    root=Path(root).resolve();checkpoint=common.absolute(args.model_dir,root)
    if (checkpoint/".moe_usage").exists():raise ValueError("persistent usage side state exists")
    env=os.environ.copy()
    commit=common.checked_text(["git","rev-parse","HEAD"],root,env)
    dirty=bool(common.checked_text(["git","status","--porcelain"],root,env))
    if dirty and not args.allow_dirty:raise ValueError("dirty tree requires exploratory --allow-dirty")
    record={"schema_version":1,"kind":"cache_admission_ab","protocol":"cache-admission-v1",
            "testbed":args.testbed,"git_commit":commit,"git_dirty":dirty,"modes":MODES,
            "checkpoint_dir":str(checkpoint),"threads":4,"cache_mib_per_layer":64,"context":512,
            "max_tokens":32,"environment_pins":model.PINS,"requests_per_block":2,
            "guards_mib":{"rss":5120,"headroom":1024,"watchdog_rss":5632,"available":1536,"swap":128},
            "notes":["fixed ABBA, 8 requests; cache counters intentionally differ",
                     "no speculative prefetch; outputs required equal; timers descriptive",
                     "frequency mode CPU-only opt-in; default always unchanged"]}
    if args.dry_run:print(json.dumps(record,indent=2));return 0
    run_id=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")+"-admission-"+uuid.uuid4().hex
    directory=common.absolute(args.output_root,root)/args.testbed/run_id
    directory.mkdir(parents=True,exist_ok=False)
    record.update(run_id=run_id,status="failed",blocks=[])
    print("Artifact: "+str(directory),flush=True)
    records=[]
    try:
        before=kernel.source_files(root)
        with model.fixed_environment():
            for i,mode in enumerate(MODES):
                block=directory/f"block-{i}-{mode}"
                argv=["--testbed",args.testbed,"--gpu","cpu","--threads","4","--cache","64",
                      "--context","512","--max-tokens","32","--lookahead","off","--memory-trace","on",
                      "--kv-buffer-reuse","off","--gate-up-mode","paired","--cache-admission",mode,
                      "--workload","kv-switch","--cycles","2","--keep-cache","--model-dir",str(checkpoint),
                      "--output-root",str(block),"--ram-limit-mib","5120","--headroom-mib","1024",
                      "--stop-rss-mib","5632","--min-available-mib","1536","--stop-swap-mib","128"]
                if args.allow_dirty:argv.append("--allow-dirty")
                code=ram.execute(ram.parser().parse_args(argv))
                paths=list(block.rglob("result.json"))
                if len(paths)!=1:raise ValueError("missing child result")
                r=json.loads(paths[0].read_text())
                record["blocks"].append({"mode":mode,"path":str(paths[0].relative_to(directory)),
                                         "run_id":r["run_id"],"status":r["status"]})
                if code:raise ValueError("child failed; stop protocol")
                validate_block(r,mode)
                if records:compare_blocks(records[0],r)
                records.append(r)
                if kernel.source_files(root)!=before:raise ValueError("source changed")
        record["summary"]=summarize(records)
        record["status"]="completed"
    except Exception as exc:record["error"]=str(exc)
    finally:common.write_exclusive_json(directory/"result.json",record)
    print(record["status"]+": "+str(directory/"result.json"),flush=True)
    return 0 if record["status"]=="completed" else 1
