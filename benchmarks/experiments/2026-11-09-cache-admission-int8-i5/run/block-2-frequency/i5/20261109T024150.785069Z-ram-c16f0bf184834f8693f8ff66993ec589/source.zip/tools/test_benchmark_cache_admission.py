"""Admission protocol tests with fake records only."""
import contextlib
import io
from pathlib import Path
import unittest
from unittest.mock import patch
import benchmark_cache_admission as admission
from test_benchmark_gate_up_model import record as gate_record
import run_benchmark as runner


def record(mode,loads):
    r=gate_record("paired")
    r["config"].update(cache_admission=mode,output_root=mode,max_tokens=32)
    for status in [r["status_start"],*(t["status"] for t in r["turns"])]:
        status["cache_admission"]=mode
    for t in r["turns"]:
        m=t["response"]["metrics"]
        m.update(cache_admission=mode,expert_cache_admission_bypasses=3 if mode=="frequency" else 0,
                 expert_file_loads=loads,expert_file_bytes_read=loads*100)
    return r


class AdmissionProtocolTests(unittest.TestCase):
    def test_valid_modes_allow_changed_work_but_same_outputs(self):
        a,b=record("always",100),record("frequency",90)
        admission.validate_block(a,"always");admission.validate_block(b,"frequency")
        admission.compare_blocks(a,b)

    def test_missing_mode_or_bad_baseline_bypass_fails(self):
        for kind in ("mode","bypass"):
            r=record("always",100)
            if kind=="mode":r["status_start"]["cache_admission"]="frequency"
            else:r["turns"][0]["response"]["metrics"]["expert_cache_admission_bypasses"]=1
            with self.assertRaises(ValueError):admission.validate_block(r,"always")

    def test_drift_output_source_and_config_fail(self):
        for kind in ("output","source","config"):
            a,b=record("always",100),record("frequency",90)
            if kind=="output":b["turns"][0]["response"]["text"]="changed"
            elif kind=="source":b["binary_sha256"]="changed"
            else:b["config"]["max_tokens"]=64
            with self.assertRaises(ValueError):admission.compare_blocks(a,b)

    def test_each_prompt_pair_must_pass_not_pooled_average(self):
        records=[record("always",100),record("frequency",90),record("frequency",90),record("always",200)]
        s=admission.summarize(records)
        self.assertTrue(s["passes_payload_rule"])
        self.assertEqual(s["pairs"][2]["file_loads"]["always"],200)
        records[2]["turns"][1]["response"]["metrics"]["expert_file_loads"]=201
        self.assertFalse(admission.summarize(records)["passes_payload_rule"])

    def test_preview_does_not_load_or_run_and_rejects_other_config(self):
        args=runner.parser().parse_args(["--testbed","i5","--gpu","cpu","--cache-admission-ab",
                                        "--threads","4","--cache","64","--context","512",
                                        "--max-tokens","32","--lookahead","off","--allow-dirty","--dry-run"])
        with patch.object(admission.common,"checked_text",return_value="test"),              patch.object(admission.ram,"execute",side_effect=AssertionError("load")),              contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(admission.execute(args,Path.cwd()),0)
            args.cache=128
            with self.assertRaises(ValueError):admission.execute(args,Path.cwd())


if __name__=="__main__":unittest.main()
