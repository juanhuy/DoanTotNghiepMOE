//! Application facade; OLMoE work runs off the async executor, one request at a time.
use crate::{generation::Generation, model::DecoderModel, olmoe::OlmoeModel};
use serde::{Deserialize, Serialize};
use std::{
    io,
    path::Path,
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};

const MAX_MESSAGES: usize = 128;
const MAX_MESSAGE_BYTES: usize = 64 * 1024;
const DEFAULT_STREAM_SEND_TIMEOUT: Duration = Duration::from_secs(30);
const DEFAULT_MAX_STREAM_DURATION: Duration = Duration::from_secs(300);

pub type InferenceResponse = Generation;
#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ChatMessage {
    pub role: String,
    pub content: String,
}

fn validate_messages(messages: &[ChatMessage]) -> io::Result<()> {
    let valid_roles = messages
        .iter()
        .all(|message| matches!(message.role.as_str(), "system" | "user" | "assistant"));
    let bytes = messages.iter().try_fold(0usize, |total, message| {
        total.checked_add(message.content.len())
    });
    if messages.is_empty()
        || messages.len() > MAX_MESSAGES
        || !valid_roles
        || bytes.is_none_or(|bytes| bytes > MAX_MESSAGE_BYTES)
    {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "messages must be nonempty, use supported roles, and stay within request limits",
        ));
    }
    Ok(())
}

fn validate_session_id(session_id: Option<&str>) -> io::Result<()> {
    if session_id.is_some_and(|id| {
        id.is_empty()
            || id.len() > 128
            || !id
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_' | b'.'))
    }) {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "session_id must contain 1-128 ASCII letters, digits, '.', '-' or '_'",
        ));
    }
    Ok(())
}

enum Model {
    Tiny(Box<DecoderModel>),
    Olmoe(Arc<Mutex<OlmoeModel>>),
}
pub struct InferenceEngine {
    model: Model,
    gate: Arc<tokio::sync::Semaphore>,
    cached_status: Arc<std::sync::RwLock<Option<crate::olmoe::ExpertStatusReport>>>,
}
impl InferenceEngine {
    pub async fn load(
        directory: impl AsRef<Path>,
        cache_bytes_per_layer: usize,
    ) -> io::Result<Self> {
        Self::load_with_limits(
            directory,
            cache_bytes_per_layer,
            512,
            3 * 1024 * 1024 * 1024,
        )
        .await
    }
    pub async fn load_with_limits(
        directory: impl AsRef<Path>,
        cache: usize,
        context: usize,
        dense: usize,
    ) -> io::Result<Self> {
        Self::load_with_gpu_mode(
            directory,
            cache,
            context,
            dense,
            crate::gpu::GpuMode::from_environment()?,
        )
        .await
    }

    pub async fn load_with_gpu_mode(
        directory: impl AsRef<Path>,
        cache: usize,
        context: usize,
        dense: usize,
        gpu_mode: crate::gpu::GpuMode,
    ) -> io::Result<Self> {
        let directory = directory.as_ref().to_owned();
        let (model, initial_status) = if directory.join("model.json").exists() {
            (
                Model::Tiny(Box::new(DecoderModel::load(directory, cache).await?)),
                None,
            )
        } else {
            let (model, status) = tokio::task::spawn_blocking(move || {
                let model =
                    OlmoeModel::load_with_gpu_mode(directory, cache, context, dense, gpu_mode)?;
                model.require_chat()?;
                let status = model.expert_status();
                Ok::<_, io::Error>((model, status))
            })
            .await
            .map_err(io::Error::other)??;
            (Model::Olmoe(Arc::new(Mutex::new(model))), Some(status))
        };
        Ok(Self {
            model,
            gate: Arc::new(tokio::sync::Semaphore::new(1)),
            cached_status: Arc::new(std::sync::RwLock::new(initial_status)),
        })
    }
    pub fn model_name(&self) -> &'static str {
        match self.model {
            Model::Tiny(_) => "tiny-moe",
            Model::Olmoe(_) => "olmoe",
        }
    }
    pub fn expert_status(&self) -> Option<crate::olmoe::ExpertStatusReport> {
        match &self.model {
            Model::Tiny(_) => None,
            Model::Olmoe(model) => {
                if let Ok(model) = model.try_lock() {
                    let status = model.expert_status();
                    if let Ok(mut cache) = self.cached_status.write() {
                        *cache = Some(status.clone());
                    }
                    Some(status)
                } else {
                    // Trả snapshot cuối cùng nếu model đang bận tính toán suy luận (không block async thread)
                    self.cached_status.read().ok().and_then(|c| c.clone())
                }
            }
        }
    }
    pub fn toggle_gpu(&self) -> io::Result<Option<crate::gpu::GpuTierStatus>> {
        match &self.model {
            Model::Tiny(_) => Ok(None),
            Model::Olmoe(model) => {
                let mut model = model.try_lock().map_err(|e| match e {
                    std::sync::TryLockError::WouldBlock => io::Error::new(
                        io::ErrorKind::WouldBlock,
                        "model is busy generating; retry after current request completes",
                    ),
                    std::sync::TryLockError::Poisoned(_) => io::Error::other("model lock poisoned"),
                })?;
                let status = model.toggle_gpu();
                if let Ok(mut cache) = self.cached_status.write() {
                    *cache = Some(model.expert_status());
                }
                Ok(Some(status))
            }
        }
    }
    pub fn set_gpu_enabled(&self, enabled: bool) -> io::Result<Option<crate::gpu::GpuTierStatus>> {
        match &self.model {
            Model::Tiny(_) => Ok(None),
            Model::Olmoe(model) => {
                let mut model = model.try_lock().map_err(|e| match e {
                    std::sync::TryLockError::WouldBlock => io::Error::new(
                        io::ErrorKind::WouldBlock,
                        "model is busy generating; retry after current request completes",
                    ),
                    std::sync::TryLockError::Poisoned(_) => io::Error::other("model lock poisoned"),
                })?;
                let status = model.set_gpu_enabled(enabled);
                if let Ok(mut cache) = self.cached_status.write() {
                    *cache = Some(model.expert_status());
                }
                Ok(Some(status))
            }
        }
    }
    pub fn toggle_kv_fp8(&self) -> io::Result<Option<bool>> {
        match &self.model {
            Model::Tiny(_) => Ok(None),
            Model::Olmoe(model) => {
                let mut model = model.try_lock().map_err(|e| match e {
                    std::sync::TryLockError::WouldBlock => io::Error::new(
                        io::ErrorKind::WouldBlock,
                        "model is busy generating; retry after current request completes",
                    ),
                    std::sync::TryLockError::Poisoned(_) => io::Error::other("model lock poisoned"),
                })?;
                let state = model.toggle_kv_fp8();
                if let Ok(mut cache) = self.cached_status.write() {
                    *cache = Some(model.expert_status());
                }
                Ok(Some(state))
            }
        }
    }
    pub fn is_kv_fp8(&self) -> bool {
        match &self.model {
            Model::Tiny(_) => false,
            Model::Olmoe(model) => {
                if let Ok(model) = model.try_lock() {
                    model.is_kv_fp8()
                } else {
                    self.cached_status
                        .read()
                        .ok()
                        .and_then(|c| c.as_ref().map(|s| s.kv_fp8))
                        .unwrap_or(false)
                }
            }
        }
    }
    /// Xóa toàn bộ bộ đệm trong hệ thống (KV cache, RAM cache, VRAM cache) để đưa về Cold Start
    pub fn reset_cache(&self) -> io::Result<()> {
        self.reset_cache_with_policy(None)
    }

    /// Optionally switch expert storage policy while idle, clearing all cached
    /// requests/experts under the same model lock before the next generation.
    pub fn reset_cache_with_policy(&self, policy: Option<&str>) -> io::Result<()> {
        if policy.is_some_and(|value| !matches!(value, "inclusive" | "victim")) {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "invalid expert cache policy",
            ));
        }
        match &self.model {
            Model::Tiny(_) => Ok(()),
            Model::Olmoe(model) => {
                let mut model = model.try_lock().map_err(|e| match e {
                    std::sync::TryLockError::WouldBlock => io::Error::new(
                        io::ErrorKind::WouldBlock,
                        "model is busy generating; retry after current request completes",
                    ),
                    std::sync::TryLockError::Poisoned(_) => io::Error::other("model lock poisoned"),
                })?;
                model.reset_cache_with_policy(policy)?;
                if let Ok(mut cache) = self.cached_status.write() {
                    *cache = Some(model.expert_status());
                }
                Ok(())
            }
        }
    }
    pub async fn generate(&self, prompt: &str) -> io::Result<InferenceResponse> {
        self.generate_with_limit(prompt, 32).await
    }
    pub async fn generate_with_limit(
        &self,
        prompt: &str,
        max_tokens: usize,
    ) -> io::Result<InferenceResponse> {
        match &self.model {
            Model::Tiny(model) => model.generate(prompt, max_tokens).await,
            Model::Olmoe(model) => {
                let permit = self.gate.clone().try_acquire_owned().map_err(|_| {
                    io::Error::new(
                        io::ErrorKind::WouldBlock,
                        "model busy; retry after current generation",
                    )
                })?;
                let model = model.clone();
                let prompt = prompt.to_owned();
                tokio::task::spawn_blocking(move || {
                    let _permit = permit;
                    model
                        .lock()
                        .map_err(|_| io::Error::other("model lock poisoned"))?
                        .generate(&prompt, max_tokens)
                })
                .await
                .map_err(io::Error::other)?
            }
        }
    }
    pub async fn chat(
        &self,
        messages: Vec<ChatMessage>,
        max_tokens: usize,
    ) -> io::Result<InferenceResponse> {
        self.chat_with_session(messages, max_tokens, None).await
    }

    pub async fn chat_with_session(
        &self,
        messages: Vec<ChatMessage>,
        max_tokens: usize,
        session_id: Option<String>,
    ) -> io::Result<InferenceResponse> {
        self.chat_with_session_and_sampling(messages, max_tokens, session_id, None)
            .await
    }

    pub async fn chat_with_session_and_sampling(
        &self,
        messages: Vec<ChatMessage>,
        max_tokens: usize,
        session_id: Option<String>,
        sampling: Option<crate::sample::SamplingParams>,
    ) -> io::Result<InferenceResponse> {
        validate_messages(&messages)?;
        validate_session_id(session_id.as_deref())?;
        match &self.model {
            Model::Tiny(model) => {
                let mut prompt = String::new();
                for m in messages {
                    prompt.push_str(&format!("{}: {}\n", m.role, m.content));
                }
                prompt.push_str("assistant: ");
                model.generate(&prompt, max_tokens).await
            }
            Model::Olmoe(model) => {
                let permit = self.gate.clone().try_acquire_owned().map_err(|_| {
                    io::Error::new(
                        io::ErrorKind::WouldBlock,
                        "model busy; retry after current generation",
                    )
                })?;
                let model = model.clone();
                tokio::task::spawn_blocking(move || {
                    let _permit = permit;
                    let mut model = model
                        .lock()
                        .map_err(|_| io::Error::other("model lock poisoned"))?;
                    let prompt = model.render_chat(&messages)?;
                    model.generate_controlled_with_sampling(
                        &prompt,
                        max_tokens,
                        session_id.as_deref(),
                        &|| Ok(()),
                        || Ok(()),
                        None,
                        sampling,
                    )
                })
                .await
                .map_err(io::Error::other)?
            }
        }
    }

    pub async fn encode(&self, text: &str) -> io::Result<Vec<usize>> {
        match &self.model {
            Model::Tiny(_) => Err(io::Error::new(
                io::ErrorKind::Unsupported,
                "token encoding requires OLMoE model",
            )),
            Model::Olmoe(model) => {
                let model = model
                    .lock()
                    .map_err(|_| io::Error::other("model lock poisoned"))?;
                model.encode(text)
            }
        }
    }

    pub async fn decode(&self, tokens: &[usize]) -> io::Result<String> {
        match &self.model {
            Model::Tiny(_) => Err(io::Error::new(
                io::ErrorKind::Unsupported,
                "token decoding requires OLMoE model",
            )),
            Model::Olmoe(model) => {
                let model = model
                    .lock()
                    .map_err(|_| io::Error::other("model lock poisoned"))?;
                model.decode(tokens)
            }
        }
    }

    pub async fn compute_perplexity(
        &self,
        text: &str,
    ) -> io::Result<crate::olmoe::PerplexityMetrics> {
        match &self.model {
            Model::Tiny(_) => Err(io::Error::new(
                io::ErrorKind::Unsupported,
                "perplexity evaluation requires OLMoE model",
            )),
            Model::Olmoe(model) => {
                let permit = self.gate.clone().try_acquire_owned().map_err(|_| {
                    io::Error::new(
                        io::ErrorKind::WouldBlock,
                        "model busy; retry after current generation",
                    )
                })?;
                let model = model.clone();
                let text = text.to_string();
                tokio::task::spawn_blocking(move || {
                    let _permit = permit;
                    let mut model = model
                        .lock()
                        .map_err(|_| io::Error::other("model lock poisoned"))?;
                    model.compute_perplexity(&text)
                })
                .await
                .map_err(io::Error::other)?
            }
        }
    }
}

/// Bounded output queue. Dropping the receiver cancels the blocking producer.
// Keep the existing public event API; expanded telemetry is carried only by the
// terminal event. Queue capacity remains bounded independently of token count.
#[allow(clippy::large_enum_variant)]
pub enum ChatEvent {
    Delta(String),
    Finished(Generation),
}

pub struct ChatStream {
    receiver: tokio::sync::mpsc::Receiver<io::Result<ChatEvent>>,
}
impl ChatStream {
    pub async fn recv(&mut self) -> Option<io::Result<ChatEvent>> {
        self.receiver.recv().await
    }
}
impl futures_core::Stream for ChatStream {
    type Item = io::Result<ChatEvent>;
    fn poll_next(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Self::Item>> {
        self.receiver.poll_recv(cx)
    }
}

fn blocking_stream_send(
    runtime: &tokio::runtime::Handle,
    sender: &tokio::sync::mpsc::Sender<io::Result<ChatEvent>>,
    timeout: Duration,
    item: io::Result<ChatEvent>,
) -> io::Result<()> {
    runtime.block_on(async {
        tokio::time::timeout(timeout, sender.send(item))
            .await
            .map_err(|_| {
                io::Error::new(
                    io::ErrorKind::TimedOut,
                    "stream client did not consume output before timeout",
                )
            })?
            .map_err(|_| io::Error::new(io::ErrorKind::Interrupted, "client disconnected"))
    })
}

impl InferenceEngine {
    /// Returns only after prompt validation. Busy/input errors remain HTTP errors.
    pub async fn chat_stream(
        &self,
        messages: Vec<ChatMessage>,
        max_tokens: usize,
    ) -> io::Result<ChatStream> {
        self.chat_stream_with_timeout(messages, max_tokens, DEFAULT_STREAM_SEND_TIMEOUT)
            .await
    }

    pub async fn chat_stream_with_timeout(
        &self,
        messages: Vec<ChatMessage>,
        max_tokens: usize,
        send_timeout: Duration,
    ) -> io::Result<ChatStream> {
        self.chat_stream_with_session(messages, max_tokens, None, send_timeout)
            .await
    }

    pub async fn chat_stream_with_session(
        &self,
        messages: Vec<ChatMessage>,
        max_tokens: usize,
        session_id: Option<String>,
        send_timeout: Duration,
    ) -> io::Result<ChatStream> {
        self.chat_stream_with_session_and_sampling(
            messages,
            max_tokens,
            session_id,
            send_timeout,
            None,
        )
        .await
    }

    pub async fn chat_stream_with_session_and_sampling(
        &self,
        messages: Vec<ChatMessage>,
        max_tokens: usize,
        session_id: Option<String>,
        send_timeout: Duration,
        sampling: Option<crate::sample::SamplingParams>,
    ) -> io::Result<ChatStream> {
        validate_messages(&messages)?;
        validate_session_id(session_id.as_deref())?;
        if send_timeout.is_zero() {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "stream send timeout must be positive",
            ));
        }
        let Model::Olmoe(model) = &self.model else {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "streaming requires OLMoE",
            ));
        };
        let permit = self.gate.clone().try_acquire_owned().map_err(|_| {
            io::Error::new(
                io::ErrorKind::WouldBlock,
                "model busy; retry after current generation",
            )
        })?;
        let model = model.clone();
        let (tx, receiver) = tokio::sync::mpsc::channel(8);
        // Keep receiver in this future, so aborting validation also cancels the worker.
        let stream = ChatStream { receiver };
        let (ready_tx, ready_rx) = tokio::sync::oneshot::channel();
        let panic_tx = tx.clone();
        let runtime = tokio::runtime::Handle::current();
        let worker = tokio::task::spawn_blocking(move || {
            let _permit = permit;
            let mut ready_tx = Some(ready_tx);
            let cancelled = || io::Error::new(io::ErrorKind::Interrupted, "client disconnected");
            let overall_deadline = Instant::now() + DEFAULT_MAX_STREAM_DURATION;
            let result = (|| {
                let mut model = model
                    .lock()
                    .map_err(|_| io::Error::other("model lock poisoned"))?;
                let prompt = model.render_chat(&messages)?;
                model.generate_controlled_with_sampling(
                    &prompt,
                    max_tokens,
                    session_id.as_deref(),
                    &|| {
                        if tx.is_closed() {
                            Err(cancelled())
                        } else if Instant::now() > overall_deadline {
                            Err(io::Error::new(
                                io::ErrorKind::TimedOut,
                                "stream exceeded maximum allowed request duration",
                            ))
                        } else {
                            Ok(())
                        }
                    },
                    || {
                        ready_tx
                            .take()
                            .unwrap()
                            .send(Ok(()))
                            .map_err(|_| cancelled())
                    },
                    Some(&mut |delta| {
                        let now = Instant::now();
                        let remaining = overall_deadline.saturating_duration_since(now);
                        if remaining.is_zero() {
                            return Err(io::Error::new(
                                io::ErrorKind::TimedOut,
                                "stream exceeded maximum allowed request duration",
                            ));
                        }
                        let timeout = send_timeout.min(remaining);
                        blocking_stream_send(
                            &runtime,
                            &tx,
                            timeout,
                            Ok(ChatEvent::Delta(delta.to_owned())),
                        )
                    }),
                    sampling,
                )
            })();
            match result {
                Ok(result) => {
                    let now = Instant::now();
                    let remaining = overall_deadline.saturating_duration_since(now);
                    let timeout = send_timeout.min(remaining);
                    let _ = blocking_stream_send(
                        &runtime,
                        &tx,
                        timeout,
                        Ok(ChatEvent::Finished(result)),
                    );
                }
                Err(error) => {
                    if let Some(ready_tx) = ready_tx {
                        let _ = ready_tx.send(Err(error));
                    } else {
                        let now = Instant::now();
                        let remaining = overall_deadline.saturating_duration_since(now);
                        let timeout = send_timeout.min(remaining);
                        let _ = blocking_stream_send(&runtime, &tx, timeout, Err(error));
                    }
                }
            }
        });
        tokio::spawn(async move {
            if let Err(error) = worker.await {
                let _ = panic_tx.send(Err(io::Error::other(error))).await;
            }
        });
        ready_rx
            .await
            .map_err(|_| io::Error::other("generation worker stopped during validation"))??;
        Ok(stream)
    }
}

#[cfg(test)]
mod stream_queue_tests {
    use super::*;

    #[tokio::test]
    async fn full_stream_queue_times_out() {
        let (sender, _receiver) = tokio::sync::mpsc::channel(1);
        sender
            .send(Ok(ChatEvent::Delta("first".into())))
            .await
            .unwrap();
        let runtime = tokio::runtime::Handle::current();
        let started = std::time::Instant::now();
        let error = tokio::task::spawn_blocking(move || {
            blocking_stream_send(
                &runtime,
                &sender,
                Duration::from_millis(20),
                Ok(ChatEvent::Delta("blocked".into())),
            )
            .unwrap_err()
        })
        .await
        .unwrap();
        assert_eq!(error.kind(), io::ErrorKind::TimedOut);
        assert!(started.elapsed() < Duration::from_secs(1));
    }
}
